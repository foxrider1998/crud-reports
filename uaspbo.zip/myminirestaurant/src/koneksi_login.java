
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


public class koneksi_login {
Connection con;
Statement stm; 

public void config(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost/db_input", "root", "");
            stm = con.createStatement();
        } catch (Exception ex) {
            Logger.getLogger(koneksi_login.class.getName()).log(Level.SEVERE, null, ex);
        }
    
}   
}
